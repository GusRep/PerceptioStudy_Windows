#ifndef DATA_STORAGE
#define DATA_STORAGE


// STATES
#define SETUP 0
#define BETWEEN_TRIALS 1
#define WAITING_FOR_INPUT 2
#define WAITING_FOR_ENTER 3

// break points
#define BREAK1 79
#define BREAK2 159


// CONDITION ORDERS
#define TRIALS_MAX 240
#define NUM_CONDITIONS 24
extern const int orderVec[12];
extern const int orders[4][10];
extern const int conditionOrders[10][NUM_CONDITIONS];
#endif
